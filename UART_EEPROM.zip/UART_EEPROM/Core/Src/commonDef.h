#ifndef COMMON_DEF_H_
#define COMMON_DEF_H_
#include "stm32f4xx_hal.h"


typedef enum
{
    E_STATUS_FAILED=0,
    E_STATUS_SUCCESS,
}e_status;


#endif /*COMMON_DEF_H_*/
